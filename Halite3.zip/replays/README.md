Replays and error logs will appear here if you use the run_game.sh or run_game.bat scripts.
